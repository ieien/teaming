<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 分页查询发表的帖子（未过期的，用于显示在小程序首页），每页数量10<br>
 * @param $page '第几页'
 */
function find_posts_in_homepage($page){

    $conn = mysql_connect::get_SQL_connect();
    if($conn){

        $sql = "call select_in_homepage($page);";
        $result = $conn->query($sql);

        if(!$result){
            echo_encode_json(2, '查询失败');

        }else{
            if($result->num_rows > 0){
                $post_list = array();
                while ($row = $result->fetch_assoc()){
                    $post_list[] = $row;
                }
                echo_encode_json(0, $post_list);
            }else{
                echo_encode_json(3, '没有更多信息了');
            }
        }

    }else{
        echo_encode_json(1, '数据库连接失败');
    }

    $conn->close();

}



$page = $_GET['page'];

find_posts_in_homepage($page);


