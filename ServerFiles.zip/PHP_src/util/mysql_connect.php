<?php

/**
 * Class mysql_connect<br/>
 * 连接Teaming数据库的工具类
 */
class mysql_connect{

    private static $ip="localhost";  //一站式部署中，为数据库内网地址
    private static $user="teaming_user";  //数据库初始用户名和密码
    private static $psw="Nchu123456?";
    private static $dbname="Teaming"; //要访问的数据库
    //private static $connect;  //数据库连接对象

    /**
     * 创建并返回数据库连接对象
     * @return mysqli
     */
    public static function get_SQL_connect(){
        //创建数据库连接对象
        $connect = new mysqli(self::$ip, self::$user, self::$psw, self::$dbname );
        $connect->query("SET NAMES utf8");  //设置编码方式
        //如果连接失败
        if($connect->connect_error){
            die("connection failed:" .$connect->connect_error);
        }

        return $connect;
    }

}

//$conn = MysqlConnect::get_SQL_connect();
//$sql="SELECT college_id,college_name FROM Teaming.college";
//$result= $conn->query($sql);
//
//                            // $_GET[] 超全局数组，通过键获取请求中传过来的值
//if($result->num_rows > 0 && $_GET["need"] == "college"){
//
//    $rows = array();
//    //从结果集中取得一行作为关联数组
//    while($row=$result->fetch_assoc()){
//        array_push($rows, $row);
//    }
//    $res = array(
//        "code" => 0,
//        "data" => $rows
//    );
//    echo json_encode($res);   ///将数组转换为json格式并通过echo返回
//}else{
//    echo "query failed";
//}


?>
