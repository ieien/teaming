<?php


/**
 * 通过登陆凭证获取openid
 * @param $code 登陆凭证
 * @return string openid
 */
function code2Session ($code) {
    $url = 'https://api.weixin.qq.com/sns/jscode2session?appid=wxbab42a511757db2c&secret=fd01e5e852f7bb0cdb0b8800bfd76c6d&js_code='.$code.' &grant_type=authorization_code';
    // 启动一个CURL会话
    $curl = curl_init();
    // 要访问的地址
    curl_setopt($curl, CURLOPT_URL, $url);
    // 对认证证书来源的检查
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
    // 从证书中检查SSL加密算法是否存在
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);
    //参数为1表示传输数据，为0表示直接输出显示
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    // 执行操作
    $output = curl_exec($curl);
    curl_close($curl);  //关闭会话
    //return $output;  // 返回数据，json格式

    //截取info数据中的openid
    $index = strrpos($output.data,"openid\":\"");
    $str_id = substr($output.data,$index+9);
    $openid = substr($str_id, 0, -6);

    return $openid;
}