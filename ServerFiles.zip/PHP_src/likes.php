<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 给帖子点赞<br>
 * @param $news_id '帖子id'
 */
function like($news_id){

    $conn = mysql_connect::get_SQL_connect();
    if($conn){

        $sql = "update news set likes = likes + 1 where news_id = $news_id;";
        $result = $conn->query($sql);

        if($result){
            echo_encode_json(0, '更新成功');
        }else{
            echo_encode_json(2, "更新失败");
        }

    }else{
        echo_encode_json(1, '数据库连接失败');
    }

    $conn->close();

}



$news_id = $_GET['news_id'];

like($news_id);



