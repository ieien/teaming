<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 修改帖子<br>
 * @param $news_id '帖子id'
 */
function modify($news_id, $title, $num_people, $aim_college, $detail, $stage){

    $conn = mysql_connect::get_SQL_connect();
    if($conn){

        $sql = "update news set title = '$title',
                num_people = $num_people,
                aim_college = $aim_college,
                detail = '$detail',
                stage = '$stage',
                news_remain_time = 10
            where news_id = $news_id;";
        $result = $conn->query($sql);

        if($result){
            echo_encode_json(0, '修改成功');
        }else{
            echo_encode_json(2, "修改失败");
        }

    }else{
        echo_encode_json(1, '数据库连接失败');
    }

    $conn->close();

}



$news_id = $_POST['news_id']; //id
$title = $_POST['title'];  //标题
$num_people = $_POST['num_people'];  //目前人数
$aim_college = $_POST['aim_college'];  //意向学院id
$detail = $_POST['detail'];  //需求详情
$stage = $_POST['stage'];  //进展

modify($news_id, $title, $num_people, $aim_college, $detail, $stage);



