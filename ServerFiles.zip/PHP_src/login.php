<?php
/**
 * 获取用户信息
 */
require "util/mysql_connect.php";
require "util/echo_encode_json.php";
require "util/code2Session.php";

//登陆凭证
$code = $_GET["code"];
//openid
$openid = code2Session($code);
//$info =  code2Session($code);
//echo $info;
//$json = json_decode($info); //对json数据解码
//$arr = get_object_vars($json);
//$openid = $arr['openid'];
//$session_key = $arr['session_key'];

$conn = mysql_connect::get_SQL_connect(); //获得连接对象
//$sql = "set @id = '$openid' ; call user_info(@id);" ;  //MySQL语句
$sql = "select user_id, user_name,avatar, sex, grade, college_name, experience, qq, weixin, tel, user_introduction 
        from user, college 
        where user_id = '$openid' and user.college_id = college.college_id;";
$result = $conn->query($sql);  //执行语句

//若有结果
if($result->num_rows > 0 ){

    $row=$result->fetch_assoc(); //从结果集中取得一行作为关联数组
    $data = array(
        "openid" => $openid,
        "userInfo" => $row
    );
    echo_encode_json(0, $data);

//若没有结果
}else{
    $data = array(
        "openid" => $openid,
        "userInfo" => "user does's exist or query failed"
    );
    echo_encode_json(1, $data);
}

$conn->close();
?>

