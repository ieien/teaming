<?php

require_once ("util/mysql_connect.php");

$conn = mysql_connect::get_SQL_connect();

$a = "软件学院";
$sql = "select * from college where college_name = '$a'";
$res = $conn->query($sql);
$arr = $res->fetch_assoc();
//echo $arr['college_id']." ".$arr['college_name'];
echo json_encode($arr['college_name']."这是中文");

$conn->close();
