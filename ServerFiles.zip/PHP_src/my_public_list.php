<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 获得某用户发布的信息，不查询信息详情，只得到一个列表<br>
 * @param $user_id '要查询的用户id
 */
function getMyPublicList($user_id){

    $conn = mysql_connect::get_SQL_connect();
    if($conn){

        $sql = "call my_public_news('$user_id');";
        $result = $conn->query($sql);

        if(!$result){
            echo_encode_json(2, '查询发布信息失败');
        }else{
            if($result->num_rows > 0){

                $my_public_list = array();
                while ($row = $result->fetch_assoc()){
                    $post = array(
                        'news_id' => $row['news_id'],
                        'title' => $row['title'],
                        'views' => $row['views'],
                        'likes' => $row['likes'],
                        'remain_time' => $row['news_remain_time'],
                        'post_time' => $row['post_time']
                    );
                    $my_public_list[] = $post;
                }
                echo_encode_json(0, $my_public_list);

            }else{
                echo_encode_json(3, '未发布信息');
            }
        }
    }else{
        echo_encode_json(1, '查询发布信息失败（数据库连接失败）');
    }




    $conn->close();

}



$user_id = $_GET['user_id'];

getMyPublicList($user_id);