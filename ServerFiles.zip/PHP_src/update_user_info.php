<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 用户注册或者信息更新，将用户信息录入到数据库中
 */
$is_sign_up = $_POST['is_sign_up'];  //注册信息还是更新信息,true表示注册
$college = $_POST['college'];      //用户所属学院
$openid = $_POST['openid'];   //用户openid
$user_name = $_POST['userName'];  //用户姓名
$avatar = $_POST['avatar'];  //头像
$sex = $_POST['sex'];    //性别
$grade = $_POST['grade'];   //年级
$experience = $_POST['experience'];  //经历
$qq = $_POST['qq'];   //QQ
$weixin = $_POST['weixin'];   //微信
$tel = $_POST['tel'];  //电话
$introduction = $_POST['introduction'];  //简介

$conn = mysql_connect::get_SQL_connect();
//因为传过来的是学院名称，而用户表中存储的是编号，所以要先获得学院编号
$sql = "select * from college where college_name = '$college'";
$result = $conn->query($sql);

if($result){
    $row = $result->fetch_assoc();
    $college_id = $row['college_id'];

    if($is_sign_up == "true"){  //注册信息

        $sql = "insert into 
        user(user_id, user_name, avatar, sex, college_id, grade, experience, qq, weixin, tel, user_introduction) 
        values
        ('$openid', '$user_name', '$avatar', '$sex', $college_id, '$grade', '$experience', 
        '$qq', '$weixin', '$tel', '$introduction');";

        $result = $conn->query($sql);

        if($result){
            echo_encode_json(0, '注册成功');
        }else{
            echo_encode_json(2, "注册失败");
        }

    }else{  //更新信息

        $sql = "update user 
                set user_name = '$user_name', avatar = '$avatar', sex = '$sex', college_id = $college_id,
                    grade = '$grade', experience = '$experience', qq = '$qq', 
                    weixin = '$weixin', tel = '$tel', user_introduction = '$introduction'
                where  user_id = '$openid';";

        $result = $conn->query($sql);

        if($result){
            echo_encode_json(0, '更新成功');
        }else{
            echo_encode_json(2, "更新失败");
        }
    }

}else{
    echo_encode_json(1, "数据库操作失败");
}

$conn->close();


