<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 查询帖子详细信息<br>
 * @param $news_id '帖子id'
 */
function get_post_detail($news_id){

    $conn = mysql_connect::get_SQL_connect();
    if($conn){

        $sql = "call post_detail($news_id);";
        $result = $conn->query($sql);

        if(!$result){
            echo_encode_json(2, '查询失败');

        }else{
            if($result->num_rows > 0){
                echo_encode_json(0, $result->fetch_assoc());
            }else{
                echo_encode_json(3, '信息不存在');
            }
        }

    }else{
        echo_encode_json(1, '数据库连接失败');
    }

    $conn->close();

}



$news_id = $_GET['news_id'];

get_post_detail($news_id);



